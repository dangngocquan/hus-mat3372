package hus.oop.midterm.books;

public class MyLinkedListNode {
    private Object payload;
    private MyLinkedListNode next;

    public MyLinkedListNode(Object payload) {
        /* TODO */
    }

    public MyLinkedListNode(Object payload, MyLinkedListNode next) {
        /* TODO */
    }

    public Object getPayload() {
        /* TODO */
    }

    public MyLinkedListNode getNext() {
        /* TODO */
    }

    public void setNext(MyLinkedListNode node) {
        /* TODO */
    }
}
