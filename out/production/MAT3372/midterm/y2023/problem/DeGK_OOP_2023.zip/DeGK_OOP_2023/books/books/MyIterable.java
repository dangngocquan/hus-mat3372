package hus.oop.midterm.books;

public interface MyIterable {
    MyIterator iterator();
}
