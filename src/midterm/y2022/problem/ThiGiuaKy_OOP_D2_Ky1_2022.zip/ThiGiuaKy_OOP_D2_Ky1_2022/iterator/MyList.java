package com.iterator;

import java.util.ArrayList;

public class MyList implements MyIterable {
	private ArrayList<String> menuItems;
 
	public MyList() {
		menuItems = new ArrayList<String>();
	}

	public void addItem(String name) {
		/* TODO */
	}
 
	public ArrayList<String> getMenuItems() {
		/* TODO */
	}
  
	public Iterator createIterator() {
		/* TODO */
	}
  
	public String toString() {
		/* TODO */
	}
}
