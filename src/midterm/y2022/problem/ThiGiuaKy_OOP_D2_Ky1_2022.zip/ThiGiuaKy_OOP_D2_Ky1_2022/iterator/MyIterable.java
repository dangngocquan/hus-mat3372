package com.iterator;

public interface MyIterable {
	public Iterator createIterator();
}
